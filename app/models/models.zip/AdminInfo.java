package models;

/**
 * Created by abzalsahitov@gmail.com  on 4/23/18.
 */
public class AdminInfo {
    public static final String EMAIL = "admin@gmail.com";
    public static final String USERNAME = "admin";
    public static final String PASSWORD = "admin";

}
