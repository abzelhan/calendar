package models;

/**
 * Created by abzalsahitov@gmail.com  on 4/23/18.
 */
public enum Weeks {

}
